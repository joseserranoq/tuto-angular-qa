import { StubShopDataAccess } from './stub-shop-data-access';

describe('StubShopDataAccess', () => {
  it('should create an instance', () => {
    expect(new StubShopDataAccess()).toBeTruthy();
  });
});
