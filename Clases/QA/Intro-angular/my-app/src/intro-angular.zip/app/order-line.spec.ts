import { Order } from './order';
import { OrderLine } from './order-line';

// describe('OrderLine', () => {
//   it('should create an instance', () => {
//     expect(new OrderLine(1234,1,
//       new Order(123, dataAccess);
//       o.setLines(1234, 2,o))).toBeTruthy();
//   });
// });
