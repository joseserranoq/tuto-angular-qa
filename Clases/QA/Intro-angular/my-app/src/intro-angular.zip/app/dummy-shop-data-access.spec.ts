import { DummyShopDataAccess } from './dummy-shop-data-access';

describe('DummyShopDataAccess', () => {
  it('should create an instance', () => {
    expect(new DummyShopDataAccess()).toBeTruthy();
  });
});
